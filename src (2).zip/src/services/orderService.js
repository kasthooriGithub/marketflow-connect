import { db } from 'lib/firebase';
import {
    collection,
    addDoc,
    getDocs,
    query,
    where,
    doc,
    updateDoc,
    Timestamp,
    orderBy
} from 'firebase/firestore';

export const orderService = {
    async createOrder(data) {
        const ordersRef = collection(db, 'orders');

        const orderData = {
            client_id: data.client_id,
            vendor_id: data.vendor_id,
            service_id: data.service_id,
            service_name: data.service_name,
            total_amount: data.total_amount,
            status: 'pending', // Default status
            payment_status: 'unpaid',
            created_at: Timestamp.now(),
            updated_at: Timestamp.now(),
        };

        const docRef = await addDoc(ordersRef, orderData);

        return {
            id: docRef.id,
            ...orderData
        };
    },

    async getOrdersByClient(clientId) {
        const ordersRef = collection(db, 'orders');
        // Removed orderBy to avoid requiring a composite index immediately.
        // Once an index is created in Firebase Console, you can add orderBy('created_at', 'desc') back.
        const q = query(ordersRef, where('client_id', '==', clientId));
        const querySnapshot = await getDocs(q);

        return querySnapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        })).sort((a, b) => b.created_at - a.created_at); // Sort client-side
    },

    async getOrdersByVendor(vendorId) {
        const ordersRef = collection(db, 'orders');
        const q = query(ordersRef, where('vendor_id', '==', vendorId));
        const querySnapshot = await getDocs(q);

        return querySnapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        })).sort((a, b) => b.created_at - a.created_at); // Sort client-side
    },

    async updateOrderStatus(orderId, status) {
        const orderRef = doc(db, 'orders', orderId);
        await updateDoc(orderRef, {
            status,
            updated_at: Timestamp.now()
        });
    }
};
